[![](https://poggit.pmmp.io/shield.state/Oneblock)](https://poggit.pmmp.io/p/RedSkyBlock)
[![](https://poggit.pmmp.io/shield.api/Oneblock)](https://poggit.pmmp.io/p/RedSkyBlock)
[![](https://poggit.pmmp.io/shield.dl.total/Oneblock)](https://poggit.pmmp.io/p/RedSkyBlock)

<img src="https://play-lh.googleusercontent.com/RY0k-vbWIgnPYXU4XciUYaay6C_vvjUv85rf1bb0NrSLOHylIBNSCZkIkyiCRtCbT-A" width="100" height="100" align="left"></img>

# OneBlock
Oneblock is an island survival plugin for pocketmine-mp. with the same appearance as skyblock but the features are much more interesting.


[![Discord](https://img.shields.io/discord/965662639168569394.svg?label=&logo=discord&logoColor=ffffff&color=7389D8&labelColor=6A7EC2)](https://discord.gg/KrjD6t9HJt)

# Installation and Support
Installing this plugin on your server is super easy to do! Just download the OneBlock.phar file from poggit and plop it into your server's plugins folder then start the server.

If you wish to request features, or notify me about an issue, please, make an issue. I will be sure to read it and reply quickly and appropriately. If you are reporting an issue with the plugin, be sure to include as many details as possible and steps to reproduce the issue. If you wish to suggest something for the plugin PLEASE be sure to include "suggestions" or "requests" in the title of the issue; make sure to be descriptive when asking for a feature, so I can be sure to know how to implement it, if I choose to do so.

# Features (completed and coming soon)
- Main Features
  - [x] Easy setup
  - [x] With tier that generate blocks
  - [x] Fun

# Depends

- You need to download and install [Multiworld](https://poggit.pmmp.io/p/MultiWorld/1.7.0-beta4) to use this plugin.

# Commands

| **Command** | **Description** |
| --- | --- |
| **/oneblock** | **Oneblock Commands** |
